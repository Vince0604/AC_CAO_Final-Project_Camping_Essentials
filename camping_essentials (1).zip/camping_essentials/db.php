<?php
$servername = "localhost"; // or your server IP
$username = "root"; // default username for XAMPP
$password = ""; // default password for XAMPP (empty)
$dbname = "camping_essentials"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
