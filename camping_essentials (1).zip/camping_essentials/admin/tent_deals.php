<?php
// Include the database connection
include('db.php');

// Handle Create (Add New Tent Deal)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $tent_deals = $_POST['tent_deals'];
    $availability = $_POST['availability'];
    $price = $_POST['price'];
    $tent_description = $_POST['tent_description'];
    $tent_tagline = $_POST['tent_tagline'];
    $image_url = $_POST['image_url'];

    // Insert query to add new tent deal
    $insert_sql = "INSERT INTO tents (tent_deals, availability, price, tent_description, tent_tagline, image_url) 
                   VALUES ('$tent_deals', '$availability', '$price', '$tent_description', '$tent_tagline', '$image_url')";
    $conn->query($insert_sql);
}

// Handle Update (Edit Tent Deal)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $tent_id = $_POST['tent_id'];
    $availability = $_POST['availability'];
    $price = $_POST['price'];

    // Update query to modify tent deal
    $update_sql = "UPDATE tents SET availability='$availability', price='$price' 
                   WHERE tentid=$tent_id";
    $conn->query($update_sql);
}

// Handle Delete (Remove Tent Deal)
if (isset($_GET['delete'])) {
    $tent_id = $_GET['delete'];
    // Delete query to remove a tent deal
    $delete_sql = "DELETE FROM tents WHERE tentid=$tent_id";
    $conn->query($delete_sql);
}

// Query to fetch tent deals from the database
$search_term = isset($_GET['search']) ? $_GET['search'] : '';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'price'; // Default sort by price
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC'; // Default sort ascending

// Sanitize input
$search_term = $conn->real_escape_string($search_term);
$sort_by = $conn->real_escape_string($sort_by);
$sort_order = $conn->real_escape_string($sort_order);

if ($search_term == '') {
    $sql = "SELECT * FROM tents ORDER BY $sort_by $sort_order";
} else {
    $sql = "SELECT * FROM tents WHERE tent_deals LIKE '%$search_term%' 
            OR tent_description LIKE '%$search_term%' 
            OR tent_tagline LIKE '%$search_term%' 
            ORDER BY $sort_by $sort_order";
}

// Execute the query
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tent Deals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
        }
        a {
            text-decoration: none;
            color: #ffffff;
        }

        /* Navbar */
        .navbar {
            background-color: #1a1a1a;
            padding: 15px 0;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ff7f3f;
        }
        .nav-link {
            margin-right: 15px;
        }

        /* Product Card Section */
        .deals-container {
            padding: 50px 20px;
        }
        .product-card {
            background-color: #252525;
            border: 1px solid #333;
            border-radius: 10px;
            color: #ffffff;
            transition: transform 0.2s, box-shadow 0.3s;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .product-card img {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            object-fit: cover;
            width: 100%;
            height: 200px; /* Set a fixed height */
        }
        .product-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.5);
        }
        .product-card .btn {
            background-color: #ff7f3f;
            border: none;
            color: white;
            margin-top: auto; /* Push the button to the bottom */
        }
        .product-card .btn:hover {
            background-color: #e56b2e;
        }

        /* Availability Styling */
        .availability {
            font-weight: bold;
            margin-top: 10px;
        }

        /* Sorting UI */
        .sort-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px; /* Add spacing to move it above the cards */
        }
        .sort-label {
            font-size: 1rem;
            color: #ff7f3f;
            font-weight: bold;
        }
        .sort-dropdown {
            background-color: #333;
            border: 1px solid #555;
            color: white;
            border-radius: 5px;
            padding: 5px 15px;
            font-size: 1rem;
            cursor: pointer;
        }
        .sort-dropdown:hover {
            background-color: #ff7f3f;
            border-color: #ff7f3f;
        }

        /* Overlay Modal */
        .modal-backdrop {
            z-index: 1050;
        }
        .modal-content {
            background-color: #252525;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Camping Essentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Admin</a>
                    </li>
                    <!-- Add Tent Deal Button -->
                    <li class="nav-item">
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#addModal">Add Tent Deal</button>
                    </li>
                </ul>
                <!-- Search Form -->
                <form class="d-flex ms-3" id="search-form" method="get">
                    <input class="form-control me-2" type="search" id="search" name="search" placeholder="Search Tents" value="<?php echo htmlspecialchars($search_term); ?>" aria-label="Search">
                    <button class="btn btn-outline-warning" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <!-- CRUD Operations -->
    <section class="deals-container">
        <div class="container">
            <h2 class="text-center mb-5">Explore Our Tent Deals</h2>

            <div class="sort-container">
                <label for="sort_by" class="sort-label">Sort by:</label>
                <select id="sort_by" class="sort-dropdown">
                    <option value="price" <?php echo $sort_by == 'price' ? 'selected' : ''; ?>>Price</option>
                    <option value="availability" <?php echo $sort_by == 'availability' ? 'selected' : ''; ?>>Availability</option>
                </select>
                <label for="sort_order" class="sort-label">Order:</label>
                <select id="sort_order" class="sort-dropdown">
                    <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                    <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Descending</option>
                </select>
            </div>

            <div class="row mt-5" id="product-container">
                <?php
                // Check if there are any results
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $tentid = $row['tentid'];
                        $tent_deals = $row['tent_deals'];
                        $availability = $row['availability'];
                        $price = $row['price'];
                        $tent_description = $row['tent_description'];
                        $tent_tagline = $row['tent_tagline'];
                        $image_url = $row['image_url'];

                        echo "
                        <div class='col-md-4 mb-4'>
                            <div class='product-card text-center p-3'>
                                <img src='assets/$image_url' alt='$tent_deals'>
                                <h5 class='mt-3'>$tent_deals</h5>
                                <p>$tent_description</p>
                                <p>$tent_tagline</p>
                                <h6 class='text-success'>$$price</h6>
                                <p class='availability'>$availability Available</p>
                                <button class='btn w-100 mt-2' data-bs-toggle='modal' data-bs-target='#editModal' data-id='$tentid' data-price='$price' data-availability='$availability'>Edit</button>
                                <a href='?delete=$tentid' class='btn btn-danger w-100 mt-2'>Delete</a>
                            </div>
                        </div>
                        ";
                    }
                } else {
                    echo "<p class='text-center text-white'>No tent deals available at the moment.</p>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Add Tent Deal Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add New Tent Deal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="tent_deals" class="form-label">Tent Name</label>
                            <input type="text" class="form-control" id="tent_deals" name="tent_deals" required>
                        </div>
                        <div class="mb-3">
                            <label for="availability" class="form-label">Availability</label>
                            <input type="number" class="form-control" id="availability" name="availability" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="tent_description" class="form-label">Tent Description</label>
                            <textarea class="form-control" id="tent_description" name="tent_description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="tent_tagline" class="form-label">Tent Tagline</label>
                            <input type="text" class="form-control" id="tent_tagline" name="tent_tagline" required>
                        </div>
                        <div class="mb-3">
                            <label for="image_url" class="form-label">Image URL</label>
                            <input type="text" class="form-control" id="image_url" name="image_url" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-warning" name="create">Add Tent</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Tent Deal Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Tent Deal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="tent_id" id="tent_id">
                        <div class="mb-3">
                            <label for="availability" class="form-label">Availability</label>
                            <input type="number" class="form-control" id="availability" name="availability" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="price" name="price" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-warning" name="update">Update</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>

    <!-- Bootstrap Script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set modal data from the button click for Edit
        $('#editModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var tentid = button.data('id');
            var price = button.data('price');
            var availability = button.data('availability');
            var modal = $(this);
            modal.find('#tent_id').val(tentid);
            modal.find('#price').val(price);
            modal.find('#availability').val(availability);
        });

        $(document).ready(function(){
            function loadTents(search_term = '', sort_by = '', sort_order = '') {
                $.ajax({
                    url: window.location.href,
                    method: 'GET',
                    data: {search: search_term, sort_by: sort_by, sort_order: sort_order},
                    success: function(response) {
                        $('#product-container').html($(response).find('#product-container').html());
                    }
                });
            }

            // Listen for changes in search input and sort options
            $('#search').on('input', function() {
                var search_term = $('#search').val();
                var sort_by = $('#sort_by').val();
                var sort_order = $('#sort_order').val();
                loadTents(search_term, sort_by, sort_order);
            });

            // Listen for changes in sorting dropdowns
            $('#sort_by, #sort_order').on('change', function() {
                var search_term = $('#search').val();
                var sort_by = $('#sort_by').val();
                var sort_order = $('#sort_order').val();
                loadTents(search_term, sort_by, sort_order);
            });
        });
    </script>
</body>
</html>
