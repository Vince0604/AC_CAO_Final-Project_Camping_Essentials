-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2024 at 03:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `camping_essentials`
--

-- --------------------------------------------------------

--
-- Table structure for table `bikes`
--

CREATE TABLE `bikes` (
  `bike_deals_id` int(11) NOT NULL,
  `bike_deals` varchar(255) NOT NULL,
  `availability` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `bike_description` text DEFAULT NULL,
  `bike_tagline` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bikes`
--

INSERT INTO `bikes` (`bike_deals_id`, `bike_deals`, `availability`, `price`, `bike_description`, `bike_tagline`, `image_url`) VALUES
(1, 'Quick Bike Deal', 5, 120.00, 'Solo Bike for an Hour', 'For a fast escape on two wheels.', 'bike_4.jpg'),
(2, 'Leisure Loop Deal', 3, 250.00, 'Solo Bike for 3 hours', 'Take your time and explore the ride.', 'bike_1.jpg'),
(3, 'Extended Adventure Deal', 0, 350.00, 'Solo Bike for 5 Hours', 'The perfect duration for a long, leisurely ride.', 'bike_3.jpg'),
(5, 'Bike', 212, 1223.00, 'bbvjkhsa', '', 'camp4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fishing_tools`
--

CREATE TABLE `fishing_tools` (
  `fishingtools_id` int(11) NOT NULL,
  `fishingtools_deals` varchar(200) NOT NULL,
  `availability` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `fishingtools_description` text NOT NULL,
  `fishingtools_tagline` varchar(200) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fishing_tools`
--

INSERT INTO `fishing_tools` (`fishingtools_id`, `fishingtools_deals`, `availability`, `price`, `fishingtools_description`, `fishingtools_tagline`, `image_url`) VALUES
(1, 'Classic Catch Combo', 5, 100, '1 Classic chair and Fishing Rod', 'Simple gear for a relaxing fishing experience.', 'fishing_tools_2.jpg'),
(2, 'Pro Angler Package', 2, 171, '1 Camping Chair and Advanced Fishing Rod', 'Upgrade your fishing with advanced gear and comfort.', 'fishing_tools_3.jpg'),
(3, 'Elite Fisherman\'s Set', 1, 230, '1 Tackle Box and Premium Fishing Rod', 'Premium rod and tackle box for the serious angler.', 'fishing_tools_6.jpg'),
(4, 'Ultimate Fishing Experience', 4, 300, '1 Camping Chair, Tackle Box, and Premium Fishing Rod', 'Everything you need for the perfect day on the water.', 'fishing_tools_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tents`
--

CREATE TABLE `tents` (
  `tentid` int(11) NOT NULL,
  `tent_deals` varchar(255) DEFAULT NULL,
  `availability` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `tent_description` text DEFAULT NULL,
  `tent_tagline` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tents`
--

INSERT INTO `tents` (`tentid`, `tent_deals`, `availability`, `price`, `tent_description`, `tent_tagline`, `image_url`) VALUES
(1, 'Solo Serenity Package', 5, 200.00, '1 Tent and 1 Comforter', 'Your peaceful retreat, wrapped in comfort.', 'tent_4.jpg'),
(2, 'Duo Dream Package', 10, 250.00, '1 Tent and 2 Comforters', 'Perfect for two, with warmth to share.', 'tent_3.jpg'),
(3, 'Dual Shelter Bundle', 4, 350.00, '2 Tents and 2 Comforters', 'Double the space, double the adventure', 'tent_2.jpg'),
(4, 'Warm Trio Bundle', 6, 400.00, '2 Tents and 3 Comforters', 'Cozy up together for unforgettable nights outdoors.', 'tent_1.jpg'),
(6, 'Trio Bundle', 5, 500.00, '3 Tents and Comforters', 'A way of gazing trio', 'camp4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `email`) VALUES
(1, 'vince', 'vince123', 'vince123@example.com'),
(2, 'admin', 'admin123', 'admin123@example.com'),
(3, 'user', 'user123', 'user123@test.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bikes`
--
ALTER TABLE `bikes`
  ADD PRIMARY KEY (`bike_deals_id`);

--
-- Indexes for table `fishing_tools`
--
ALTER TABLE `fishing_tools`
  ADD PRIMARY KEY (`fishingtools_id`);

--
-- Indexes for table `tents`
--
ALTER TABLE `tents`
  ADD PRIMARY KEY (`tentid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bikes`
--
ALTER TABLE `bikes`
  MODIFY `bike_deals_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fishing_tools`
--
ALTER TABLE `fishing_tools`
  MODIFY `fishingtools_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tents`
--
ALTER TABLE `tents`
  MODIFY `tentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
